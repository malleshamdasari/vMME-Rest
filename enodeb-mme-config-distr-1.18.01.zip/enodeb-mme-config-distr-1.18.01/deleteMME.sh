#!/bin/bash

echo "Operation not supported"
