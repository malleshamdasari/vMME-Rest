#!/bin/bash

LOCAL_IP=$(cat /opt/config/local_private_ipaddr.txt)
MME_IP_ADDR=$1
MMC=$2
MNC=$3
GTP_BIND_ADDR=$4
N_PROB=$5
MME_PORT=36412
ENODEB_PORT=9998

./opt/eNodeB-Emulator/controller_if/bin/controller_if $ENODEB_PORT $LOCAL_IP $MME_PORT $MME_IP_ADDR
